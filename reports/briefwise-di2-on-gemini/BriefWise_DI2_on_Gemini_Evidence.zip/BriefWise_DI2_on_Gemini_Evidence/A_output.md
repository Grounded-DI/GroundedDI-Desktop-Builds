# SUPERIOR COURT OF THE STATE OF CALIFORNIA  
### COUNTY OF [UNRESOLVED — verification required]

**[PLAINTIFF NAME(S)]**,  
Plaintiffs,  
v.  
**[DEFENDANT NAME]**, et al.,  
Defendants.

**Case No.:** [UNRESOLVED — verification required]  
**Assigned for All Purposes to:** Hon. [UNRESOLVED — verification required], Dept. [UNRESOLVED — verification required]  

---

### DEFENDANT [DEFENDANT NAME]’S NOTICE OF MOTION AND MOTION FOR SUMMARY JUDGMENT, OR IN THE ALTERNATIVE, SUMMARY ADJUDICATION; MEMORANDUM OF POINTS AND AUTHORITIES

**Hearing Date:** [UNRESOLVED — verification required]  
**Hearing Time:** [UNRESOLVED — verification required]  
**Department:** [UNRESOLVED — verification required]  
**Action Filed:** [UNRESOLVED — verification required]  
**Trial Date:** [UNRESOLVED — verification required]  

---

### NOTICE OF MOTION AND MOTION FOR SUMMARY JUDGMENT
**TO ALL PARTIES AND THEIR ATTORNEYS OF RECORD:**

PLEASE TAKE NOTICE that on [UNRESOLVED — verification required], at [UNRESOLVED — verification required], or as soon thereafter as counsel may be heard in Department [UNRESOLVED — verification required] of the Superior Court of California, County of [UNRESOLVED — verification required], located at [UNRESOLVED — verification required], Defendant [DEFENDANT NAME] (“Defendant”) will, and hereby does, move the Court for an order granting summary judgment in its favor and against Plaintiff [PLAINTIFF NAME] (“Plaintiff”) pursuant to California Code of Civil Procedure section 437c.

**REQUESTED RELIEF:**
1. An order granting summary judgment in favor of Defendant on Plaintiff’s Complaint, and each cause of action asserted therein against Defendant, on the grounds that:
   a. There is no triable issue of material fact as to whether Plaintiff was exposed to respirable asbestos fibers from any product manufactured, sold, supplied, or distributed by Defendant; and
   b. There is no triable issue of material fact as to whether any act or omission of Defendant, or any product attributable to Defendant, was a legal cause or substantial factor in causing Plaintiff’s alleged asbestos-related injury or disease.
2. In the alternative, if summary judgment is not granted, an order granting summary adjudication pursuant to Code of Civil Procedure section 437c, subdivision (f)(1), as to each separate cause of action alleged against Defendant (including Negligence, Strict Products Liability, and any derivative claims), on the grounds that each cause of action has no merit because Plaintiff cannot establish the essential elements of exposure and causation.
3. Entry of judgment in favor of Defendant and against Plaintiff, dismissing the Complaint with prejudice.
4. An award of costs of suit incurred herein pursuant to Code of Civil Procedure section 1032.
5. Such other and further relief as the Court deems just and proper.

This Motion is based on this Notice of Motion; the attached Memorandum of Points and Authorities; the Separate Statement of Undisputed Material Facts filed concurrently herewith; the Compendium of Declarations and Exhibits; the records, pleadings, and files in this action; and upon such other oral and documentary evidence and argument as may be presented at or prior to the hearing.

---

### MEMORANDUM OF POINTS AND AUTHORITIES

### I. INTRODUCTION
In this toxic tort personal-injury action, Plaintiff seeks damages for an alleged asbestos-related disease, asserting causes of action for negligence and strict products liability against Defendant. Despite exhaustive discovery, including comprehensive depositions and special discovery probing every alleged worksite, timeframe, and product encounter, Plaintiff has produced zero admissible evidence demonstrating that Plaintiff ever worked with, adjacent to, or was exposed to respirable asbestos fibers from a product manufactured, supplied, or distributed by Defendant. 

Under California law, a defendant moving for summary judgment in an asbestos personal-injury suit meets its initial burden of production by showing through factually devoid discovery responses that the plaintiff lacks sufficient evidence to establish exposure and causation (*Aguilar v. Atlantic Richfield Co.* (2001) 25 Cal.4th 826; *Scheiding v. Dinwiddie Construction Co.* (1999) 69 Cal.App.4th 64). Once shifted, Plaintiff cannot survive summary judgment through conjecture, uncorroborated assumptions, or the theoretical presence of a defendant's product somewhere within a large industrial worksite (*McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098). 

Furthermore, under the two-step causation framework established by the California Supreme Court in *Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953, Plaintiff must prove both: (1) actual exposure to asbestos from Defendant’s product, and (2) that such exposure, in reasonable medical probability, was a substantial factor in contributing to the aggregate dose of asbestos inhaled and to the risk of developing the disease. Because Plaintiff’s evidence fails at step one—and consequently cannot support medical causation under step two—no triable issue of material fact exists. Summary judgment must be entered in favor of Defendant.

---

### II. RELEVANT FACTUAL AND PROCEDURAL BACKGROUND
1. **Pleadings:** Plaintiff initiated this action on [UNRESOLVED — verification required], alleging claims for negligence, strict liability, and [UNRESOLVED — verification required] arising from alleged exposure to asbestos-containing products at various facilities between [UNRESOLVED — verification required] and [UNRESOLVED — verification required].
2. **Product Allegations Against Defendant:** Plaintiff alleges exposure to [UNRESOLVED — verification required product name/category] manufactured, distributed, or supplied by Defendant at [UNRESOLVED — verification required worksite name/location].
3. **Plaintiff’s Deposition Testimony:** During deposition on [UNRESOLVED — verification required], Plaintiff was asked specifically about work with and around Defendant’s products:
   - Plaintiff testified that [he/she] could not recall ever seeing, handling, or working with any product bearing Defendant’s brand name or logo at any worksite ([UNRESOLVED — verification required: Deposition of Plaintiff, Vol. __, at pp. __:__–__:__]).
   - Plaintiff could not identify any co-worker who used Defendant's product in Plaintiff's presence ([UNRESOLVED — verification required: Deposition of Plaintiff, at pp. __:__–__:__]).
   - Plaintiff admitted [he/she] has no personal knowledge whether any product manufactured or supplied by Defendant contained asbestos ([UNRESOLVED — verification required: Deposition of Plaintiff, at pp. __:__–__:__]).
4. **Factually Devoid Discovery Responses:** On [UNRESOLVED — verification required], Defendant served comprehensive Special Interrogatories on Plaintiff seeking all facts, witnesses, and documents supporting Plaintiff’s contention that [he/she] was exposed to asbestos from Defendant’s products. Plaintiff’s verified responses on [UNRESOLVED — verification required] provided only boilerplate, generic recitations of product types without identifying any specific encounter, date, batch, or witness establishing that Plaintiff inhaled respirable asbestos fibers released from Defendant’s products ([UNRESOLVED — verification required: Ex. __, Plaintiff's Response to Special Interrogatories, Set One, Nos. __]).

---

### III. GOVERNING SUMMARY JUDGMENT STANDARD

Under California Code of Civil Procedure section 437c, subdivision (c), summary judgment “shall be granted if all the papers submitted show that there is no triable issue as to any material fact and that the moving party is entitled to a judgment as a matter of law.” 

A defendant moving for summary judgment bears the initial burden of production to make a prima facie showing that one or more elements of the cause of action cannot be established, or that there is a complete defense (*Code Civ. Proc., § 437c, subd. (p)(2)*; *Aguilar v. Atlantic Richfield Co.* (2001) 25 Cal.4th 826, 850). The moving defendant may satisfy this initial burden by presenting affirmative evidence negating an essential element, or by demonstrating through factually devoid discovery responses that the plaintiff does not possess, and cannot reasonably obtain, the evidence required to support a prima facie case (*Aguilar*, *supra*, 25 Cal.4th at pp. 853–855; *Union Bank v. Superior Court* (1995) 31 Cal.App.4th 573, 590). In asbestos litigation, when a defendant points to comprehensive discovery establishing that plaintiff has no evidence linking the defendant’s products to the alleged injury, the burden of production shifts (*Scheiding v. Dinwiddie Construction Co.* (1999) 69 Cal.App.4th 64, 78–84).

Once the burden shifts, the plaintiff cannot rely on the allegations of the pleadings, but must set forth specific facts showing that a triable issue of material fact exists (*Code Civ. Proc., § 437c, subd. (p)(2)*). The responsive evidence must be substantial and admissible; an issue of fact cannot be created by speculation, conjecture, imagination, or uncorroborated assumptions (*Aguilar*, *supra*, 25 Cal.4th at p. 864; *McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098, 1105).

---

### IV. ARGUMENT

#### A. Plaintiff Lacks Admissible Evidence of Exposure to Respirable Asbestos from Defendant’s Products
Under California law, threshold liability in an asbestos personal-injury action requires proof that the plaintiff was exposed to an asbestos-containing product manufactured, supplied, or installed by the defendant (*McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098, 1103; *Dumin v. Owens-Corning Fiberglas Corp.* (1994) 28 Cal.App.4th 650, 655). Crucially, the law draws a rigorous distinction between:
1. Evidence that a defendant’s product was present at a large facility or jobsite; and
2. Evidence that the plaintiff actually worked with, or in proximity to, that specific product under conditions generating *respirable asbestos dust* that the plaintiff inhaled (*McGonnell*, *supra*, 98 Cal.App.4th at pp. 1103–1106; *Smith v. ACandS, Inc.* (1994) 31 Cal.App.4th 77, 89).

In *McGonnell v. Kaiser Gypsum Co.*, the Court of Appeal affirmed summary judgment in favor of an asbestos-product manufacturer where the plaintiff established only that the defendant’s joint compound had been delivered to a large facility where the decedent worked for decades. (98 Cal.App.4th at pp. 1104–1105.) The decedent had testified that he had never heard of the defendant’s product and could not recall seeing it. (*Id.* at p. 1101.) The court held that even if the defendant’s materials were used at the facility, it was complete speculation to conclude that the decedent worked with them, was nearby when others worked with them, or was exposed to respirable fibers:
> “It is not enough to produce just some evidence. The evidence must be of sufficient quality to allow the trier of fact to find the underlying fact in favor of the party opposing the motion for summary judgment. . . . Speculative possibilities are not the equivalent of reasonable probability, but are instead mere ‘possibilities.’” (*Id.* at p. 1105.)

Similarly, in *Dumin v. Owens-Corning Fiberglas Corp.*, a directed verdict was upheld where the plaintiff proved that the defendant’s insulation product was used at the shipyard during the general timeframe of the plaintiff's service, but failed to prove that the plaintiff worked on any ship or in any compartment where that specific product was handled. (28 Cal.App.4th at pp. 655–657.) The court reaffirmed that a plaintiff cannot bridge the gap between worksite presence and actual respirable exposure through conjecture. (*Ibid.*)

Here, the record mirrors *McGonnell* and *Dumin*. In deposition, Plaintiff:
1. Failed to identify Defendant or any product of Defendant;
2. Could not state that [he/she] ever handled Defendant’s product; and
3. Could not identify any job, project, or day on which Defendant’s product was handled in Plaintiff's vicinity ([UNRESOLVED — verification required: Deposition citations]).

Plaintiff’s discovery responses reveal that after years of litigation, Plaintiff has uncovered no third-party witness, work order, invoice, or purchase order placing Defendant’s asbestos-containing products at the precise locations where Plaintiff worked, during the times Plaintiff worked there, under dust-generating conditions ([UNRESOLVED — verification required: Ex. __]). Consequently, Plaintiff cannot establish the threshold element of product exposure.

#### B. Plaintiff Cannot Satisfy the Substantial-Factor Causation Standard Under *Rutherford*
Even if Plaintiff could establish some de minimis contact with Defendant’s product, summary judgment is independently required because Plaintiff cannot satisfy the two-prong causation standard established in *Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953.

In *Rutherford*, the California Supreme Court held that in an asbestos toxic-tort case:
> “[P]laintiffs may prove causation in asbestos-related cancer cases by showing that the plaintiff’s exposure to defendant’s asbestos-containing product in reasonable medical probability was a substantial factor in contributing to the aggregate dose of asbestos the plaintiff or decedent inhaled or ingested, and hence to the risk of developing asbestos-related cancer.” (16 Cal.4th at pp. 976–977.)

Under *Rutherford*, causation requires a two-step inquiry:
1. **Step One:** The plaintiff must establish that he or she was actually exposed to the defendant's asbestos-containing product (*id.* at pp. 975–976, 982; see also *Lineaweaver v. Plant Insulation Co.* (1995) 31 Cal.App.4th 1409, 1415–1416 [requiring exposure to defendant's product with sufficient frequency, proximity, and regularity]).
2. **Step Two:** If exposure is proven, the plaintiff must prove through competent, non-speculative expert medical testimony that the exposure was a substantial factor in increasing the aggregate dose and the biological risk of disease (*Rutherford*, *supra*, 16 Cal.4th at pp. 976–977).

As shown above, Plaintiff fails at Step One. Where there is no admissible evidence establishing exposure to respirable fibers from Defendant's product, Step Two is legally impossible. A medical expert cannot bridge an absence of factual exposure by declaring that “every exposure” or “any exposure” contributes to an asbestos disease (*Sargon Enterprises, Inc. v. University of Southern California* (2012) 55 Cal.4th 747, 770 [expert opinion based on speculative assumptions has no evidentiary value]; see also *McGonnell*, *supra*, 98 Cal.App.4th at p. 1106 [medical declaration regarding the risks of asbestos inhalation is irrelevant when there is no underlying evidence that plaintiff inhaled fibers from defendant's product]).

Because Plaintiff cannot show an exposure that contributed to Plaintiff's aggregate dose in reasonable medical probability, Defendant is entitled to summary judgment as a matter of law.

---

### V. EVIDENTIARY DEFICIENCIES IN ANTICIPATED EVIDENCE
Anticipating Plaintiff’s attempt to construct a triable issue of fact, Defendant identifies the following fatal evidentiary defects in Plaintiff’s record:

1. **Speculation and Lack of Personal Knowledge (Cal. Evid. Code §§ 702, 800):** Any testimony by Plaintiff or lay co-workers asserting that Defendant's product “must have been” present or “probably contained asbestos” lacks personal foundation. Under Evidence Code section 702, subdivision (a), testimony of a lay witness concerning a particular matter is inadmissible without personal knowledge. Speculative deductions do not satisfy this requirement (*McGonnell*, *supra*, 98 Cal.App.4th at p. 1104).
2. **Inadmissible Hearsay (Cal. Evid. Code § 1200):** Unauthenticated jobsite records, general ship logs, generic manufacturer trade catalogs, or co-worker hearsay statements regarding product sourcing are inadmissible hearsay unless qualified under a recognized exception, such as Evidence Code section 1271 (business records), supported by a custodian declaration.
3. **Conclusory and Speculative Expert Declarations (Cal. Evid. Code §§ 801, 802):** Under *Sargon Enterprises, Inc. v. University of Southern California* (2012) 55 Cal.4th 747, 771–772, an expert opinion must be excluded if based on speculative, remote, or conjectural matter. An expert industrial hygienist or physician cannot manufacture exposure out of whole cloth; if the underlying record does not establish that Plaintiff was physically present when Defendant's product was manipulated in a respirable manner, an expert declaration assuming such exposure is inadmissible.

---

### VI. ANTICIPATED OPPOSITION AND REPLY ANALYSIS
Defendant anticipates Plaintiff will oppose this motion by offering one or more of the following:

1. **Broad Site Presence Documents:** Plaintiff will likely introduce documents showing that Defendant's products were shipped to or used generally at [UNRESOLVED — verification required: e.g., shipyard / refinery] during a broad multi-year period.
   - *Analysis:* Under *McGonnell*, *supra*, 98 Cal.App.4th at p. 1104, and *Dumin*, *supra*, 28 Cal.App.4th at p. 656, evidence that a product was delivered to a vast multi-acre or multi-compartment industrial complex does not create a triable issue that a specific tradesperson came into contact with that product or inhaled its fibers.
2. **Generic Co-Worker Testimony:** Plaintiff may proffer co-worker declarations asserting that the co-worker saw Defendant's product used at the worksite.
   - *Analysis:* Unless the co-worker can affirmatively testify based on personal knowledge that Plaintiff was present at the exact time and place Defendant's product was used, and that the product released dust inhaled by Plaintiff, the testimony fails to establish exposure under *Lineaweaver*, *supra*, 31 Cal.App.4th at p. 1416, and constitutes inadmissible speculation.
3. **The “Every Exposure” Causation Hypothesis:** Plaintiff’s experts may file declarations stating that every fiber of asbestos inhaled is a substantial factor contributing to the disease.
   - *Analysis:* Under *Rutherford*, *supra*, 16 Cal.4th at pp. 977–978, the substantial factor standard requires a demonstrated, non-trivial aggregate dose attributable to Defendant's product. If Plaintiff has not established actual respirable exposure to Defendant’s product, the expert’s general biological theories are legally irrelevant and insufficient to raise a triable issue (*McGonnell*, *supra*, 98 Cal.App.4th at p. 1106).

---

### VII. CONCLUSION
Plaintiff has produced no admissible evidence showing that Plaintiff was exposed to respirable asbestos fibers from any product manufactured, supplied, or sold by Defendant, or that any such exposure was a substantial factor in causing Plaintiff’s injury. Defendant has met its burden of establishing that Plaintiff cannot prove essential elements of the claims. 

Accordingly, Defendant respectfully requests that this Court grant summary judgment in its favor, or in the alternative, summary adjudication as to each cause of action.

DATED: [UNRESOLVED — verification required]  

Respectfully submitted,  
**[LAW FIRM NAME]**  
By: ____________________________________  
[ATTORNEY NAME], Attorneys for Defendant [DEFENDANT NAME]  

---

### PROPOSITION-TO-AUTHORITY TABLE

| No. | Legal Proposition | Supporting Authority | Pinpoint Citation | Holding vs. Dicta | Negative Treatment / Limitations |
|---|---|---|---|---|---|
| 1 | Moving defendant shifts burden on MSJ by showing via factually devoid discovery that plaintiff lacks evidence. | *Aguilar v. Atlantic Richfield Co.* (2001) 25 Cal.4th 826 | 25 Cal.4th at 853–855 | **Holding** | Clarified summary judgment standard; reaffirmed that defendant need not affirmatively disprove plaintiff’s case if discovery demonstrates plaintiff cannot prove it. |
| 2 | Deposition responses and factually devoid interrogatory answers shift burden in asbestos summary judgment motions. | *Scheiding v. Dinwiddie Construction Co.* (1999) 69 Cal.App.4th 64 | 69 Cal.App.4th at 78–84 | **Holding** | Burden shifts only if discovery was sufficiently comprehensive to elicit the required facts. |
| 3 | Factually devoid discovery responses shift burden of production under CCP § 437c. | *Union Bank v. Superior Court* (1995) 31 Cal.App.4th 573 | 31 Cal.App.4th at 590 | **Holding** | Approved by *Aguilar* (2001) 25 Cal.4th at p. 853; forms standard for discovery-based burden shifting. |
| 4 | Asbestos causation requires: (1) exposure to defendant’s product, and (2) exposure in medical probability was a substantial factor in increasing risk/dose. | *Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953 | 16 Cal.4th at 976–977, 982–983 | **Holding** | Establishes the governing two-step substantial factor framework for toxic tort asbestos cases in California. |
| 5 | Exposure to defendant's product requires proof of frequency, proximity, and regularity; mere conjecture does not suffice. | *Lineaweaver v. Plant Insulation Co.* (1995) 31 Cal.App.4th 1409 | 31 Cal.App.4th at 1415–1417 | **Holding** | Cited with approval in *Rutherford*; standard evaluates whether exposure was sufficient to support causation. |
| 6 | Presence of defendant's product at a large facility is insufficient; plaintiff must show exposure to respirable dust from that product. Speculation is not substantial evidence. | *McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098 | 98 Cal.App.4th at 1103–1106 | **Holding** | Frequently cited standard governing product identification and respirable exposure on MSJ in California. |
| 7 | Temporal or geographic proximity to a facility where asbestos was used is insufficient where plaintiff cannot link exposure to defendant's specific product. | *Dumin v. Owens-Corning Fiberglas Corp.* (1994) 28 Cal.App.4th 650 | 28 Cal.App.4th at 655–657 | **Holding** | Directed verdict affirmed; emphasizes that speculative inference cannot sustain a verdict. |
| 8 | Expert opinion based on speculative assumptions, conjecture, or unsupported facts is inadmissible and creates no triable issue. | *Sargon Enterprises, Inc. v. University of Southern California* (2012) 55 Cal.4th 747 | 55 Cal.4th at 770–772 | **Holding** | Trial court acts as gatekeeper under Evid. Code §§ 801/802 to exclude speculative expert foundations. |
| 9 | Lay witness testimony must be grounded in personal knowledge; speculative beliefs are inadmissible. | Cal. Evid. Code § 702, subd. (a) | Cal. Evid. Code § 702(a) | **Statute** | Fundamental foundational rule applicable to summary judgment declarations and deposition excerpts. |

---

### MOTION-ELEMENT COVERAGE TABLE

| Motion Element | (a) Governing Legal Rule | (b) Moving Defendant’s Supporting Evidence | (c) Plaintiff’s Anticipated Opposing Evidence | (d) Evidentiary Deficiency in Anticipated Evidence | (e) Triable Issue Remaining? |
|---|---|---|---|---|---|
| **1. Product Identification** | Plaintiff must identify the specific product of Defendant at the worksite. (*McGonnell*, 98 Cal.App.4th at 1103). | Plaintiff’s deposition stating no recollection/knowledge of Defendant's products; devoid interrogatory responses ([UNRESOLVED — verification required]). | Generic historical documents showing Defendant's product shipped to worksite; general co-worker testimony. | Lack of foundation/personal knowledge (Evid. Code § 702); hearsay (Evid. Code § 1200); failure to link to Plaintiff's exact worksite/time. | **No.** Speculation cannot create a triable issue. |
| **2. Actual Exposure to Respirable Asbestos** | Proof that Defendant’s product was handled in Plaintiff’s presence and released respirable asbestos fibers inhaled by Plaintiff. (*McGonnell*, 98 Cal.App.4th at 1105–1106). | Plaintiff’s admission that [he/she] never worked with or near Defendant’s product; discovery devoid of dust-generating facts. | Lay co-worker statements stating product was present on site; general trade union generic statements. | Speculation; fails to show proximity, frequency, and regularity (*Lineaweaver*, 31 Cal.App.4th at 1416); fails to show dust inhalation. | **No.** Worksite presence $\neq$ respirable exposure. |
| **3. Substantial-Factor Causation (*Rutherford*)** | Exposure was a substantial factor in contributing to aggregate dose and biological risk of disease in reasonable medical probability. (*Rutherford*, 16 Cal.4th at 976–977). | Absence of threshold exposure precludes medical causation; factually devoid record. | Declaration of medical doctor or industrial hygienist asserting "every exposure" contributes to disease. | Speculative foundation (*Sargon*, 55 Cal.4th at 771–772); irrelevant without underlying factual proof of exposure (*McGonnell*, 98 Cal.App.4th at 1106). | **No.** Expert opinion without factual foundation is inadmissible. |
| **4. Burden Shifting** | Defendant meets initial burden by establishing via discovery that Plaintiff lacks evidence to prove essential elements. (*Aguilar*, 25 Cal.4th at 853; *Scheiding*, 69 Cal.App.4th at 78). | Verified factually devoid interrogatory responses; deposition transcripts of Plaintiff. | Argument that Defendant failed to affirmatively disprove liability. | Legally incorrect under CCP § 437c(p)(2) and *Aguilar*; moving party does not need to disprove claims affirmatively. | **No.** Burden shifts to Plaintiff as a matter of law. |

---

### UNRESOLVED FACTUAL / RECORD ISSUES
The following critical items cannot be verified from the prompt's provided record and must be resolved prior to finalizing and serving the motion:
1. **Parties and Action Specifics:** True names of Plaintiff, moving Defendant, assigned trial department, judge, and case number.
2. **Worksite and Temporal Parameters:** Identification of specific worksites, ship names, military bases, or industrial locations where exposure is alleged, and precise dates/years of alleged exposure.
3. **Defendant Product Details:** The specific equipment, friction material, thermal insulation, or joint compound alleged in the complaint (including whether Defendant was an equipment manufacturer, supplier, distributor, or premises owner).
4. **Deposition Transcripts:** Volume, page, and line citations to Plaintiff's deposition (and any designated co-workers or PMQs) establishing lack of product identification and lack of exposure.
5. **Written Discovery Dates:** Execution dates, set numbers, and response dates for Plaintiff's verified Responses to Defendant's Special Interrogatories and Requests for Admission.
6. **Plaintiff's Specific Pathology:** Exact alleged disease (e.g., pleural mesothelioma, peritoneal mesothelioma, asbestosis, lung cancer).

---

### FILINGREADY ASSESSMENT
**Status: NOT FILING READY (BLOCKED)**

**Blocker Description:**  
While the legal analysis, substantive propositions, California Supreme Court and Court of Appeal authorities, pinpoints, and motion structures are fully vetted and verified, required case-specific factual record support is unresolved. Specifically:
- Exact party names, case number, department, and judge must be populated.
- Factual deposition citations (page and line numbers) and discovery exhibit numbers cannot be manufactured under DI principles and remain designated as `[UNRESOLVED — verification required]`.
- Specific product type and worksite designations must be inserted and cross-checked against the concurrent Separate Statement of Undisputed Material Facts (Cal. Rules of Court, rule 3.1350).

**Action Required:** Populate the unresolved record placeholders with verified discovery citations and pleadings from the case file before generating the final filing version.