### Notice of Motion and Motion for Summary Judgment

**TO ALL PARTIES AND TO THEIR ATTORNEYS OF RECORD:**

PLEASE TAKE NOTICE that on [Date], at [Time], or as soon thereafter as the matter may be heard in Department [Number] of the above-entitled Court, located at [Court Address], Defendant [Defendant Name] ("Defendant") will, and hereby does, move this Court for an order granting summary judgment in its favor and against Plaintiff [Plaintiff Name] ("Plaintiff") pursuant to California Code of Civil Procedure section 437c.

Defendant moves for summary judgment on the grounds that Plaintiff's complaint has no merit and that there is no triable issue of material fact as to any cause of action asserted against Defendant. Specifically, Plaintiff cannot establish two essential elements of each asserted cause of action:

1. Plaintiff cannot present admissible evidence establishing that Plaintiff was exposed to respirable asbestos fibers from any product manufactured, sold, distributed, or supplied by Defendant.
2. Plaintiff cannot establish that any exposure attributable to Defendant’s product was a substantial factor in contributing to the aggregate dose of asbestos that allegedly caused Plaintiff’s disease.

This Motion is based upon this Notice; the attached Memorandum of Points and Authorities; the Separate Statement of Undisputed Material Facts; the Declaration of [Counsel Name] and attached exhibits; the pleadings, records, and files in this action; and such oral and documentary evidence as may be presented at or before the hearing on this Motion.

---

### Memorandum of Points and Authorities

#### I. Introduction

Plaintiff initiated this action seeking damages for an asbestos-related disease allegedly caused by occupational exposure to asbestos-containing materials. However, following comprehensive, fact-specific discovery, Plaintiff cannot produce admissible evidence connecting Defendant to any actionable asbestos exposure.

Under California law, establishing liability in an asbestos personal-injury action requires a plaintiff to prove: (1) exposure to the defendant's asbestos-containing product such that the plaintiff inhaled respirable asbestos fibers from that specific product; and (2) that the exposure was a substantial factor in increasing the risk of, or contributing to, the aggregate dose causing the disease (*Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953).

Defendant has satisfied its initial burden on summary judgment by demonstrating through Plaintiff's fact-depleted, comprehensive discovery responses and deposition testimony that Plaintiff does not possess, and cannot reasonably obtain, competent admissible evidence of exposure to respirable asbestos fibers attributable to Defendant. Plaintiff's claims rest on speculation, assumptions, and impermissible stacked inferences. Because Plaintiff cannot establish either product identification/exposure or legal causation, summary judgment must be granted.

---

#### II. Relevant Factual Background

* **Plaintiff’s Allegations:** Plaintiff alleges that while working as a [Trade/Occupation] at [Worksite Name] between [Year] and [Year], Plaintiff was exposed to asbestos from products manufactured, supplied, or distributed by Defendant, resulting in the diagnosis of [Alleged Disease, e.g., Mesothelioma / Asbestosis / Lung Cancer] on [Date].
* **Discovery Undertaken:** Defendant propounded comprehensive, case-wide special interrogatories, requests for admissions, and requests for production demanding all facts, witnesses, and documents supporting Plaintiff’s contention that Plaintiff worked with or around Defendant’s products containing asbestos.
* **Plaintiff’s Factually Devoid Responses:** In response to Defendant's comprehensive discovery, Plaintiff identified:
* Depositions/Testimony: UNRESOLVED — verification required
* Specific Product Identification: UNRESOLVED — verification required
* Asbestos Content Verification: UNRESOLVED — verification required

* **Plaintiff’s Deposition:** At deposition, Plaintiff testified regarding work history, co-workers, and materials handled:
* Plaintiff could not definitively identify Defendant's brand name, logo, packaging, or product: UNRESOLVED — verification required
* Plaintiff acknowledged having no personal knowledge of whether the materials handled contained asbestos: UNRESOLVED — verification required
* Plaintiff failed to testify to respirable dust generation from any product attributed to Defendant: UNRESOLVED — verification required

---

#### III. Governing Summary Judgment Standard

A defendant moving for summary judgment bears the initial burden of production to make a prima facie showing that one or more elements of the cause of action cannot be established, or that there is a complete defense (Code Civ. Proc., § 437c, subd. (p)(2); *Aguilar v. Atlantic Richfield Co.* (2001) 25 Cal.4th 826, 850).

A defendant meets this burden in one of two ways:

1. By presenting affirmative evidence negating an essential element of the plaintiff's claim; or
2. By demonstrating through "factually devoid" or factually depleted discovery responses that the plaintiff does not possess, and cannot reasonably obtain, needed evidence to support an essential element (*Aguilar*, *supra*, 25 Cal.4th at pp. 854–855; *Scheiding v. General Motors Corp.* (2000) 22 Cal.4th 471, 479–481; *Union Bank v. Superior Court* (1995) 31 Cal.App.4th 573, 590–593).

Once the moving defendant meets this burden, the burden shifts to the plaintiff to produce admissible, substantial evidence showing that a triable issue of one or more material facts exists (Code Civ. Proc., § 437c, subd. (p)(2); *Aguilar*, *supra*, 25 Cal.4th at p. 849). To defeat summary judgment, the plaintiff cannot rely on the allegations of the pleadings, nor upon speculative, conjectural, or theoretical possibilities (*Sangster v. Paetkau* (1998) 68 Cal.App.4th 151, 163). "Speculation, however, is not evidence." (*Jolley v. Chase Home Finance, LLC* (2013) 213 Cal.App.4th 872, 897). Where the opposition relies upon an inference, that inference must be a reasonable deduction from the evidence, not mere guesswork (*Bravo v. Baxter Healthcare Corp.* (2024) 99 Cal.App.5th 611, 622).

---

#### IV. Argument: Plaintiff Cannot Establish Essential Elements

**A. Plaintiff Cannot Prove Identification of and Exposure to Defendant's Asbestos Product**

To survive summary judgment in an asbestos personal-injury action, the plaintiff must first establish threshold exposure to the defendant's asbestos-containing product (*Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953, 982). Proximity alone to a worksite is insufficient; the plaintiff must show actual exposure to respirable asbestos fibers released from a product for which the defendant is legally responsible (*McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098, 1103–1105; *Dumin v. Owens-Corning Fiberglas Corp.* (1994) 28 Cal.App.4th 650, 655–657).

1. *Mere Presence at a Worksite Is Legally Insufficient:* Under *McGonnell v. Kaiser Gypsum Co.*, the Court of Appeal affirmed summary judgment where the plaintiff established that the defendant’s compound was delivered to the facility where the decedent worked, but could not place the decedent in contact with that compound generating respirable dust (*McGonnell*, *supra*, 98 Cal.App.4th at pp. 1104–1105). The court ruled that it is not enough to show that a defendant’s product was somewhere in a facility; the plaintiff must present evidence that the plaintiff actually worked with or in immediate proximity to the product when it emitted asbestos dust.
2. *Proof of Product Encounter Does Not Equal Proof of Asbestos Exposure:* Merely encountering a component or material bearing a defendant's label does not establish actionable exposure. Plaintiff must show that the specific product encountered actually contained asbestos at that precise point in time, and that the product was manipulated or disturbed in a manner that generated airborne, respirable asbestos fibers that Plaintiff inhaled. Speculation that a product might have contained asbestos or might have emitted dust is inadmissible and insufficient as a matter of law (*Smith v. ACandS, Inc.* (1994) 31 Cal.App.4th 77, 89 [disapproved on other grounds in *Camargo v. Tjaarda Dairy* (2001) 25 Cal.4th 1235]).

**B. Plaintiff Cannot Satisfy the Substantial-Factor Causation Standard**

Even if Plaintiff could bridge the evidentiary gap regarding product identification, Plaintiff cannot meet the required standard for proving causation under California law.

In *Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953, the California Supreme Court established the two-part test for causation in asbestos personal-injury actions:

1. The plaintiff must establish exposure to defendant’s asbestos-containing product; and
2. The plaintiff must prove that the exposure was a "substantial factor" in contributing to the aggregate dose of asbestos inhaled or the risk of developing the disease (*Id.* at pp. 976–977, 982).

The *Rutherford* court emphasized that while plaintiffs need not trace a specific microscopic fiber to the cellular origin of a tumor, they *must* prove an actual, quantifiable or biologically meaningful exposure:

> "[T]he plaintiff must first establish some threshold *exposure* to the defendant's defective products, and must further establish in reasonable medical probability that a particular exposure or series of exposures was a 'substantial factor' in bringing about the injury." (*Rutherford*, *supra*, 16 Cal.4th at p. 982, italics in original.)

The court identified key factors in evaluating whether an exposure meets the substantial factor test:

* Frequency of exposure;
* Regularity of exposure;
* Proximity to the asbestos product; and
* The type and characteristics of the product and fiber release (*Id.* at p. 975).

A minor, isolated, or trace exposure cannot constitute a substantial factor (*Id.* at p. 969). In the absence of evidence establishing the frequency, regularity, and proximity of exposure to Defendant’s product, an expert's testimony declaring that "every exposure" contributes to disease is legally insufficient to defeat summary judgment (*Sargon Enterprises, Inc. v. University of Southern California* (2012) 55 Cal.4th 747, 770 [expert opinion based on speculative or unsupported assumptions carries no evidentiary value]).

---

#### V. Evidentiary Deficiencies in Plaintiff's Proof

Any evidence Plaintiff attempts to present to establish exposure or causation suffers from fatal evidentiary and foundational defects (Evid. Code, §§ 403, 702, 800, 801, 1200):

* **Lack of Personal Knowledge / Speculation (Evid. Code, §§ 702, 800):** Deposition testimony where Plaintiff or co-workers "assume" or "believe" a generic product was Defendant’s, without foundation (e.g., distinguishing markings, packaging, part numbers), is inadmissible lay speculation.
* **Hearsay (Evid. Code, § 1200):** Statements by co-workers or supervisors indicating that a product came from Defendant or contained asbestos, when offered for the truth of the matter, constitute inadmissible hearsay unless a recognized exception applies.
* **Temporal and Worksite Ambiguity:** Inability to match the presence of Defendant's product to the specific dates and job locations where Plaintiff was physically present breaks the chain of exposure (*Dumin*, *supra*, 28 Cal.App.4th at p. 656).
* **Unsubstantiated Expert Opinions (Evid. Code, § 801):** An expert declaration stating Plaintiff was exposed to Defendant's product without foundation in the record is inadmissible conjecture (*Sargon*, *supra*, 55 Cal.4th at p. 771).

---

#### VI. Anticipated Opposition and Reply Analysis

Defendant anticipates Plaintiff will attempt to create a triable issue of fact through the following arguments:

1. **"Defendant’s Products Were Present at the Facility":** Plaintiff will likely cite shipping invoices, delivery receipts, or testimony from third-party witnesses indicating that Defendant’s products were delivered to [Worksite Name].
* *Response / Controlling Law:* Presence at the facility does not establish that Plaintiff was exposed. Under *McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098, 1104, evidence that products were delivered to a multi-acre or large commercial site is insufficient without evidence placing the plaintiff in the direct operational zone where those materials were actively disturbed and releasing respirable dust.

2. **"Every Exposure Contributes" Theory:** Plaintiff will likely proffer an expert declaration asserting that all exposures to asbestos fibers above ambient background contribute to the cumulative lifetime dose and are substantial factors.
* *Response / Controlling Law:* Under *Rutherford*, exposure must be evaluated under the factors of frequency, regularity, and proximity (16 Cal.4th at p. 975). A generic expert assertion cannot substitute for factual proof of threshold exposure to Defendant's product. If there is no primary evidence of respirable fiber release from Defendant's product, the expert has no factual baseline upon which to render an opinion (*Sargon*, *supra*, 55 Cal.4th at p. 770).

---

#### VII. Conclusion

Defendant has demonstrated that Plaintiff lacks admissible evidence establishing product identification, actual respirable asbestos exposure, and substantial-factor causation. Because Plaintiff cannot establish these vital elements, summary judgment must be entered in favor of Defendant.

---

### Proposition-to-Authority Table

| Proposition | Supporting Authority | Holding vs. Dicta | Reporter Citation & Pinpoint | Negative Treatment / Limitations |
| --- | --- | --- | --- | --- |
| **Summary Judgment Burden (Factually Devoid Discovery):** A moving defendant may satisfy its initial burden by showing through factually devoid discovery responses that plaintiff does not possess and cannot reasonably obtain required evidence. | *Aguilar v. Atlantic Richfield Co.* (2001); *Scheiding v. General Motors Corp.* (2000) | **Holding** in both cases. | *Aguilar*, 25 Cal.4th 826, 854–855; *Scheiding*, 22 Cal.4th 471, 479–481. | None. Remains foundational standard in California. |
| **Exposure Requirement:** Plaintiff must establish threshold exposure to the defendant's asbestos-containing product before reaching causation. | *Rutherford v. Owens-Illinois, Inc.* (1997) | **Holding**. | *Rutherford*, 16 Cal.4th 953, 982. | None. Primary authority for asbestos causation. |
| **Substantial Factor Standard:** Causation requires showing in reasonable medical probability that exposure was a substantial factor in contributing to aggregate dose or risk, evaluated by frequency, regularity, and proximity. | *Rutherford v. Owens-Illinois, Inc.* (1997) | **Holding**. | *Rutherford*, 16 Cal.4th 953, 975, 976–977, 982. | Clarified in later cases (e.g., cannot rely on pure speculative cumulative exposure without threshold showing). |
| **Worksite Presence Insufficiency:** Showing defendant's product was present at a jobsite is insufficient without proof plaintiff was exposed to respirable asbestos dust from that product. | *McGonnell v. Kaiser Gypsum Co.* (2002) | **Holding**. | *McGonnell*, 98 Cal.App.4th 1098, 1103–1105. | None. Widely applied in California asbestos summary judgments. |
| **Inference vs. Speculation:** Inferences must be logical deductions from evidence; speculative possibilities do not create a triable issue of material fact. | *Bravo v. Baxter Healthcare Corp.* (2024); *Sangster v. Paetkau* (1998) | **Holding**. | *Bravo*, 99 Cal.App.5th 611, 622; *Sangster*, 68 Cal.App.4th 151, 163. | None. |
| **Foundational Expert Evidence:** Expert opinions based on speculation, assumption, or lack of factual foundation are inadmissible and lack evidentiary value. | *Sargon Enterprises, Inc. v. University of Southern California* (2012) | **Holding**. | *Sargon*, 55 Cal.4th 747, 770–771. | Broadly applied to all expert declarations on summary judgment. |

---

### Motion-Element Coverage Table

| Motion Element | (a) Governing Legal Rule | (b) Defendant’s Supporting Evidence | (c) Plaintiff’s Anticipated Evidence | (d) Evidentiary Deficiency | (e) Triable Issue Remaining? |
| --- | --- | --- | --- | --- | --- |
| **1. Product Identification** | *McGonnell*, 98 Cal.App.4th at 1103–1105; *Dumin*, 28 Cal.App.4th at 655–657. | Factually devoid responses to Special Interrogatories: UNRESOLVED — verification required. | Co-worker or Plaintiff deposition claiming to have seen Defendant’s boxes: UNRESOLVED — verification required. | Speculation; lack of foundation under Evid. Code, § 702; hearsay under § 1200. | No, if Plaintiff cannot authenticate product identity. |
| **2. Respirable Asbestos Exposure** | *Rutherford*, 16 Cal.4th at 982; *McGonnell*, 98 Cal.App.4th at 1104. | Plaintiff deposition admitting no knowledge of whether dust was asbestos-containing: UNRESOLVED — verification required. | Worksite delivery logs or vendor records: UNRESOLVED — verification required. | Proximity gap; no proof that product disturbed emitted respirable fibers inhaled by Plaintiff. | No, mere presence does not equal exposure. |
| **3. Substantial-Factor Causation** | *Rutherford*, 16 Cal.4th at 975, 982; *Aguilar*, 25 Cal.4th at 849. | Factually devoid discovery regarding frequency, regularity, and duration: UNRESOLVED — verification required. | Expert declaration stating "any exposure is a substantial factor": UNRESOLVED — verification required. | Excluded under *Sargon*, 55 Cal.4th at 770; lacks required baseline showing of frequency/regularity/proximity. | No. |

---

### Unresolved Factual / Record Issues

The following case-specific evidentiary and factual items are missing from the record and require direct verification:

1. **Plaintiff's Specific Worksite & Dates:** Specific dates, locations, naval vessels, or facilities where Plaintiff allegedly worked around Defendant's product (`UNRESOLVED — verification required`).
2. **Discovery Responses:** Specific discovery requests (e.g., Set and Interrogatory numbers) and verbatim responses demonstrating factually devoid disclosures (`UNRESOLVED — verification required`).
3. **Deposition Transcripts:** Specific page and line citations to Plaintiff's deposition or co-worker depositions where the witness failed to identify Defendant's products or admit lack of personal knowledge (`UNRESOLVED — verification required`).
4. **Product Verification:** Whether the product at issue was ever formulated with asbestos during the specific temporal period at issue (`UNRESOLVED — verification required`).
5. **Medical / Expert Declarations:** Identity and specific assertions of Plaintiff’s medical and industrial-hygiene experts (`UNRESOLVED — verification required`).

---

### FilingReady Assessment

**Verdict: FilingReady CANNOT be confirmed.**

**Blockers Identified:**

* **Record Evidence Incomplete:** Case-specific factual support (deposition line citations, verified interrogatory answers, and exhibits) has not been provided (`UNRESOLVED — verification required`). Under California Rules of Court, rules 3.1113 and 3.1350, every material fact in the Separate Statement and Memorandum must cite specific supporting evidence.
* **Party & Court Specifics:** Hearing dates, department number, case caption, and identified product categories remain unpopulated.
* **Affirmative Showing Verification:** Need to verify the specific answers provided by Plaintiff to ensure that Defendant's summary judgment motion properly triggers the burden-shifting mechanism under *Aguilar* and *Scheiding*.