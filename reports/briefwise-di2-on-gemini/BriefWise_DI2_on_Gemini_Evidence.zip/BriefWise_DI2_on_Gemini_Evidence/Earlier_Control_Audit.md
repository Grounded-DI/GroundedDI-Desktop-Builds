# Audit of the supplied Gemini “guesser” asbestos motion

September 12, 2026. **Not reliable for filing. The problems are substantive, not just missing names and exhibits.** The structure is usable as a planning outline, but the body exceeds both the supplied record and several cited authorities.

## Scope and method

Reviewed the complete pasted draft and compared its material claims with publicly accessible opinion texts, the current California summary-judgment statute and the official evidence-objection rule. The original generation prompt, model settings and request trace for this particular control were not supplied with the attachment; attribution as the “guesser” control is user-provided context. This is not an exhaustive citator search, a complete current-law certification, or a determination of any actual case. No case record was supplied. No material was sent back to Gemini during this audit.

“Confirmed error” below means a mismatch established by the supplied text or inspected authority. “Unverified” does not mean proven nonexistent. A valid citation does not establish that the attached proposition is valid.

## Priority findings

### 1. Confirmed: it supplies discovery history and a victory conclusion without a record

Locations: Introduction; Relevant Factual Background; Evidentiary Deficiencies; Conclusion; coverage table.

The draft asserts that comprehensive discovery occurred, that responses were factually depleted, that defendant satisfied its initial burden, and that all anticipated evidence suffers fatal defects. It concludes summary judgment must be entered. None of those propositions follows from the supplied materials. Appending “UNRESOLVED” to some deposition bullets does not make the surrounding assertions conditional. The table likewise cannot answer “No” to a triable-issue question whose evidence is unresolved.

Correction: label these as proposed arguments contingent on identified, admissible evidence. Defendant’s showing, plaintiff’s response, objections and triability must each remain UNRESOLVED until the record is supplied. This is an independent failure even if every citation were accurate.

### 2. Confirmed: wrong Scheiding opinion for the discovery burden

Locations: Summary Judgment Standard; first authority-table row.

*Scheiding v. General Motors Corp.* (2000) 22 Cal.4th 471 concerns federal locomotive/BIA preemption. Its pages 479–481 do not establish the factually-devoid-discovery rule attributed to them. Labeling that proposition a holding of this case is wrong. [Opinion](https://law.justia.com/cases/california/supreme-court/4th/22/471.html).

The relevant asbestos discovery decision is *Scheiding v. Dinwiddie Construction Co.* (1999) 69 Cal.App.4th 64, particularly 79–83. Crucially, it reversed summary judgment and explained why the inference of missing evidence was unavailable on its record. Replacing the case name without applying that limitation would still be inadequate. [Opinion](https://law.justia.com/cases/california/court-of-appeal/4th/69/64.html).

### 3. Confirmed: Rutherford is overstated, and its quotation is altered

Location: IV.B.

The categorical exclusion of minor, isolated or trace exposure is not what *Rutherford v. Owens-Illinois, Inc.* (1997) 16 Cal.4th 953, 969, 978 holds. Its substantial-factor discussion distinguishes negligible/theoretical contributions and warns against overemphasizing “substantial.” The draft also adds a mandatory quantification gloss unsupported by the cited passage.

Its block quotation is not verbatim: it drops “asbestos-containing,” removes the “legal cause” formulation and substitutes a shorter substantial-factor formulation without indicating the omissions. The general holding at 982–983 must be quoted accurately or paraphrased. Footnote 13 expressly reserves application of the discussed standards/instruction to asbestosis; the draft indiscriminately lists several diseases. [Opinion, majority and fn. 13](https://law.justia.com/cases/california/supreme-court/4th/16/953.html).

Correction: retain threshold exposure and reasonable-medical-probability causation, but do not convert relevant exposure factors into universal quantitative prerequisites. Resolve the disease and factual context first.

### 4. Confirmed material omission: Davis undermines the automatic Sargon exclusion

Locations: IV.B; Evidentiary Deficiencies; opposition/reply; causation coverage row.

*Sargon Enterprises, Inc. v. University of Southern California* (2012) 55 Cal.4th 747, 770–772 supports excluding unsupported expert reasoning. It also limits gatekeeping: the court does not decide scientific controversies or weigh an opinion’s persuasiveness as a factfinder. It is not an asbestos-specific holding that every-exposure testimony is automatically inadmissible. [Opinion](https://law.justia.com/cases/california/supreme-court/2012/s191550.html).

*Davis v. Honeywell International Inc.* (2016) 245 Cal.App.4th 477, 480 upheld the admission of the challenged every-exposure testimony against a Sargon challenge on its record. The draft omits it entirely despite promising the strongest opposition. This is material contrary authority to its categorical formulation, not a holding that every such opinion always suffices or proves missing product exposure. [Davis opinion](https://law.justia.com/cases/california/court-of-appeal/2016/b256793.html).

A proper reply would distinguish the actual expert’s factual basis and reasoning from Davis, rather than declare exclusion based on a theory’s label. Later discussion in the published portion of *Phillips v. Honeywell International Inc.* expressly distinguishes the testimony there from the every-exposure theory; it does not establish a universal contrary rule. [Phillips opinion](https://law.justia.com/cases/california/court-of-appeal/2017/f070761.html).

### 5. Confirmed overstatement: case-specific exposure failures become universal direct-proof requirements

Locations: IV.A; opposition item 1.

*McGonnell v. Kaiser Gypsum Co.* (2002) 98 Cal.App.4th 1098, 1104–1105 rejected a particular speculative chain about product use, asbestos content and the decedent’s encounters. It does not announce the draft’s universal “direct operational zone” requirement. The opinion also expressly requires favorable treatment of the nonmovant’s evidence and ambiguities. [Opinion](https://law.justia.com/cases/california/court-of-appeal/4th/98/1098.html).

*Dumin v. Owens-Corning Fiberglas Corp.* (1994) 28 Cal.App.4th 650, 656–657 explicitly permits circumstantial proof supporting a reasonable inference; the particular proof failed. *Smith v. ACandS, Inc.* (1994) 31 Cal.App.4th 77, 88–89 concerns tenuous temporal overlap and ambiguous contractor identification. It does not supply the draft’s entire exact-product/date/fiber-release checklist as a universal holding. [Dumin](https://law.justia.com/cases/california/court-of-appeal/4th/28/650.html), [Smith](https://law.justia.com/cases/california/court-of-appeal/4th/31/77.html).

Correction: analyze what reasonable inferences the complete record supports, then explain the specific missing link. Do not conflate lack of a plaintiff’s firsthand chemical knowledge with absence of all admissible evidence of asbestos content.

### 6. Unverified: Bravo; unsupported quotation attribution: Jolley

Locations: Summary Judgment Standard; inference authority-table row.

I could not locate *Bravo v. Baxter Healthcare Corp.* (2024) 99 Cal.App.5th 611, 622 through repeated exact-name and reporter-citation searches. **The citation, pinpoint and claimed holding remain unverified and cannot be used as supplied.** Search failure is not conclusive proof that no such decision exists.

The retrieved text of *Jolley v. Chase Home Finance, LLC* (2013) 213 Cal.App.4th 872 does not contain the sentence attributed to page 897 (“Speculation, however, is not evidence.”). Treat that exact quotation/pinpoint as unsupported unless a reliable reporter copy establishes it. [Jolley opinion inspected](https://law.justia.com/cases/california/court-of-appeal/2013/a134019.html).

The general distinction between speculation and sufficient responsive evidence has legitimate support in *Sangster v. Paetkau* (1998) 68 Cal.App.4th 151, 163. The existence of another supporting authority does not validate the suspect citations. [Sangster opinion](https://law.justia.com/cases/california/court-of-appeal/4th/68/151.html).

### 7. Confirmed: evidence objections and motion coverage are incomplete

The draft identifies useful categories—personal knowledge, hearsay, foundation, timing and product identity—but never ties an objection to actual testimony, an exhibit, an offered purpose, an exception or a proposed ruling. “Any evidence” is not an objection analysis. Lack of brand recall by one witness does not automatically dispose of other witnesses, records or reasonable inferences.

The official written-objection rule requires identification of the specific evidence and grounds in the prescribed format, with a proposed order. The draft does not supply these materials. [California Rules of Court, rule 3.1354](https://courts.ca.gov/cms/rules/index/three/rule3_1354).

The complaint is absent, yet the notice purports to dispose of every cause of action. The three-row coverage table omits a distinct moving-party burden analysis and does not identify the actual pleaded claims. It refers to a separate statement and declarations that were not supplied. Current Code of Civil Procedure section 437c requires evidentiary support and a separate statement; it also contains scheduling requirements, including 81-day notice and the ordinary 30-day-before-trial hearing cutoff, subject to applicable provisions and exceptions. Those requirements are not verified by blank dates. [Current section 437c](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=CCP&sectionNum=437c.).

### 8. Confirmed: the negative-treatment column and final blockers overclaim completeness

“None” in a negative-treatment column requires an actual treatment check. None is documented here. The final checklist identifies missing facts and burden-shifting support but misses the incorrect mapping, altered quotation, unverified citation and adverse authority above.

One positive detail: the draft correctly flags that *Smith* was disapproved on other grounds. *Camargo v. Tjaarda Dairy* (2001) 25 Cal.4th 1235, 1242–1245 addresses contractor/hirer liability and disapproves inconsistent cases, including Smith. That does not erase Smith’s separate exposure discussion; the precise affected proposition matters. [Camargo opinion](https://law.justia.com/cases/california/supreme-court/4th/25/1235.html).

## Compact authority disposition

| Draft authority | Audit result |
|---|---|
| Aguilar, 25 Cal.4th 826 | Core initial-burden framework is appropriate. It does not establish that this unidentified defendant actually met the burden. Inspect 850, 854–855. [Opinion](https://law.justia.com/cases/california/supreme-court/4th/25/826.html). |
| Scheiding / General Motors, 22 Cal.4th 471 | Real case; wrong proposition mapping and holding label. |
| Union Bank, 31 Cal.App.4th 573 | Relevant factually-devoid-discovery authority; record-dependent, not an automatic victory rule. [Opinion](https://law.justia.com/cases/california/court-of-appeal/4th/31/573.html). |
| Sangster, 68 Cal.App.4th 151 | Relevant responsive-evidence principle; no record application established. |
| Jolley, 213 Cal.App.4th 872 | Real opinion; supplied quotation/pinpoint not verified in retrieved text. |
| Bravo, 99 Cal.App.5th 611 | Unable to locate/verify as cited. |
| Rutherford, 16 Cal.4th 953 | Central authority, materially overstated; purported quotation altered. |
| McGonnell, 98 Cal.App.4th 1098 | Relevant; factual holding expanded into a categorical rule. |
| Dumin, 28 Cal.App.4th 650 | Relevant; preserves reasonable circumstantial inference. |
| Smith, 31 Cal.App.4th 77 | Relevant exposure discussion; cited passage does not support the entire asserted checklist. |
| Camargo, 25 Cal.4th 1235 | Treatment flag has a genuine basis; scope matters. |
| Sargon, 55 Cal.4th 747 | Relevant general gatekeeping; no automatic every-exposure exclusion. |

This table is not a clean citator report. No claim is made that every pinpoint, subsequent case, quoted passage or statutory cross-reference in the draft has been exhaustively verified.

## What the draft does reasonably well

It separates exposure and causation in its organization, identifies several genuinely relevant California appellate authorities, lists sensible evidentiary questions, leaves many record placeholders and declines FilingReady. These are useful drafting features. They do not cure a motion that assumes its evidence and overstates its cases.

## Repair and evaluation criteria

Before another draft, supply an approved authority packet and a labeled case record, or require every missing item to remain unresolved. Score each proposition separately for source identity, actual support, scope, quotation fidelity, contrary authority and record application. A real case with the wrong proposition fails; a correct general rule with invented record application also fails. Count unsupported conclusions inside tables as well as prose.

For this document the essential repairs are: replace the wrong Scheiding mapping while preserving the correct case’s limitation; remove unsupported Bravo/Jolley material; correct Rutherford; address Davis; replace invented facts and outcome conclusions with genuinely conditional analysis; and build the actual claim/evidence/objection map.

**FilingReady cannot be confirmed because required legal verification and factual support are incomplete, and confirmed substantive errors remain.** The test supports identifying these failure modes in this output. It does not establish that a particular model or “simulate” instruction caused them, or that another prompt reliably prevents them.
