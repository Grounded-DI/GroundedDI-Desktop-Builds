# Publication evidence guide

This package accompanies DI² on Gemini. Proprietary material is outside the analysis and has been replaced with marked redactions. These are publication copies, not complete original transcripts. Original records are retained privately. Legal errors and unfavorable findings have not been corrected or removed by the redaction.

A comprises the redacted API request, response and reported settings. Original reported token counts include withheld material. B comprises the supplied control request and response; exact backend model, settings, history and tools are unknown. C is the post-audit remediation. D is the subsequent model response to the paper, not independent validation or a statement by Google. Some paragraphs are withheld in full to avoid disclosing proprietary context.

The historical audit is also redacted. Paper.md supplies the current synthesis; Sources.txt identifies the consulted legal texts. No complete commercial citator examination was performed. Citation metadata is not a complete proposition-by-proposition verification log. Two HTTP 503 failures preceded A's retained success; B's attempt log is unknown.

Manifest hashes cover these redacted publication files only. They establish package consistency, not original transcript completeness, provider authentication or correctness. Publication approved by Mark S. Weinstein.
